package si2024.miguelquirogaalu.p01;

import core.game.StateObservation;

public interface Mundo {
	public void analizarMundo(StateObservation stateObs);
}
