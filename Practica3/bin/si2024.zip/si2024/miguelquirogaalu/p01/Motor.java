package si2024.miguelquirogaalu.p01;

public interface Motor {
	
	public Regla disparo(Mundo m);
	
	public Regla resolucionConflicto();
}
