package si2024.miguelquirogaalu.p01;

import ontology.Types.ACTIONS;

public interface Accion {
	public ACTIONS doAction(Mundo m);
}
