package si2024.miguelquirogaalu.p01;

public interface Condicion {
	public boolean seCumple(Mundo m);
}
