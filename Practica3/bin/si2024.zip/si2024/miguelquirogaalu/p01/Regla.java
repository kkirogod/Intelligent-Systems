package si2024.miguelquirogaalu.p01;

public interface Regla {

	public boolean seCumple(Mundo m);
	public Accion getAccion();
}
