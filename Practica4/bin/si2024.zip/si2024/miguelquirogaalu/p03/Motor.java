package si2024.miguelquirogaalu.p03;

public abstract class Motor {
	public abstract Accion piensa(Mundo m);
}
