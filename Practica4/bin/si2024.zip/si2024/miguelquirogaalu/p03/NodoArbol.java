package si2024.miguelquirogaalu.p03;

public abstract class NodoArbol {
	
	public abstract NodoArbol decide(Mundo m);
}
