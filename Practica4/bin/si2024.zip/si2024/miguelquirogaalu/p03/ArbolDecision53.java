package si2024.miguelquirogaalu.p03;

public class ArbolDecision53 extends ArbolDecision {

	public ArbolDecision53() {
		raiz = new Decision1_2();
	}
}

// 1º 1_2
// 2º 1_3
// 3º 1

// MATAR ENF -> +2
// INFECTAR -> +1
// ENF TE CURA -> -1